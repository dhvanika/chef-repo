name "securitylevel_red"
description "Security level 'red'"
override_attributes(
  "firewall" => {
    "securitylevel" => "red"
  }
  )
