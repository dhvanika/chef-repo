maintainer       "Paul Chapotet"
maintainer_email "paul@scalr.com"
license          "All rights reserved"
description      "Install of OSQA - Apache Server - Ubuntu"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.1"
