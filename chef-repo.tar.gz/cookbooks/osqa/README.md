Description
===========

OSQA - The Open Source Q&A System

Recipe "osqa-apache" installs and configures OSQA with apache.
Recipe "osqa-database" installs and configures OSQA with mySQL.

Requirements
============
Platform
--------

* Ubuntu

Tested on:

* Ubuntu 10.04

Attributes
==========
You need to configure all attributes